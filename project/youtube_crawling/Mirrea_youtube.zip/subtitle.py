import time ,random

from selenium import webdriver
from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver =webdriver.Chrome()

link = "https://www.youtube.com/watch?v=TmTSczyw6lg"
driver.get(link)
time.sleep(3)

더보기_셀렉터 = "#button-shape > button > yt-touch-feedback-shape > div > div.yt-spec-touch-feedback-shape__fill"
더보기_버튼 = driver.find_element(By.CSS_SELECTOR, 더보기_셀렉터)
더보기_버튼.click()
time.sleep(2)
스크립트_보기_셀렉터 = "#items > ytd-menu-service-item-renderer"
스크립트_보기_예비후보들 = driver.find_elements(By.CSS_SELECTOR,스크립트_보기_셀렉터)
스크립트_진짜_후보 = None
for 스크립트_보기_예비후보 in 스크립트_보기_예비후보들:
    if 스크립트_보기_예비후보.text =="스크립트 표시":
        스크립트_진짜_후보 = 스크립트_보기_예비후보
        break
스크립트_진짜_후보.click()
time.sleep(2)


스크립트표기_셀렉터 = "#primary-button > ytd-button-renderer > yt-button-shape > button > yt-touch-feedback-shape > div > div.yt-spec-touch-feedback-shape__fill"
element = driver.find_element(By.CSS_SELECTOR, 스크립트표기_셀렉터)
driver.execute_script("arguments[0].click();", element)

time.sleep(10)

#1. 스크립트 탭에서 스크립트 내용 전체 추출하기
스크립트_탭_셀렉터 = "#segments-container > ytd-transcript-segment-renderer"
스크립트_탭들 = driver.find_elements(By.CSS_SELECTOR, 스크립트_탭_셀렉터)

결과값 =[]
# 스크립트를 통해서 유튜브 자막을 추출하게됩니다.
for 스크립트_탭 in 스크립트_탭들:
    
    결과값.append(스크립트_탭.text)
    
#2. 타임라인 제거하는 방법
타임라인제거_결과값 =[ ]
타임라인제거_결과값 = [텍스트.split("\n")[1] +" " for 텍스트 in 결과값 ]
print(타임라인제거_결과값)

#3. 결과값을 텍스트 파일로 저장하기
with open("스크립트.txt",'w',encoding='utf8') as f:
    f.writelines(타임라인제거_결과값)
input()

